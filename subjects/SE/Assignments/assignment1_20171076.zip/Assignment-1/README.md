# Software Engineering Assignment 1

- **Roll Number:** 20171076
- **Name:** Zubair Abid

## Explanation of Implemented Features

### Overview

`Args` is a library? of sorts that is initialised with a *schema* (that is, rules defining how something should be dealt with) and *arguments* (a sequence of flags and variables).

The *arguments* are what is acted on in the library. For sake of clarity, let's consider an example:

```
schema = "p#,q##"
```

This means that the flag `-p` will preface an integer and this should be dealt with accordingly, and the flag `-q` will preface a Double, also to be dealt with.

```
arguments = "-p", "42", "-q", "420.69"
```

This means that the number 42 will be stored in the object `args` of `Args`, accessible via the flag 'p', which is to say you can `args.getInt('p')` to return 42. Likewise for double

### Control Flow of the program

On initialising the `Args` object, with a [schema](#schema) and an [argument list](#args), we:

- Init:
    - `marshalers`, a map from characters to [Argument Marshalers](#marshalers)
    - `argsFound`, a set of all characters found so far
- Parse:
    - the schema, using `parseSchema`:
        - we take each *comma-separated element* of the schema (which is a comma-separated list of `char+indicator` elements), and pass it to `parseSchemaElement` where each element is split into:
            - an `elementId` - which has to be a single character to be valid (the validator, `validSchemaElementId` just checks if the character is a letter or not), 
            - and the rest of the string, which has to be a specific character combination. This combination is used to decide which `ArgumentMarshaler` will be associated with the `elementId`
            - So, at the end of this you have a new entry to the `marshalers` map: the `elementId` and the associated marshaler, both extracted from `element`
        - Now, **`marshalers` is a map for all comma-separated `elements` of the `schema` to an associated `ArgumentMarshaler`**
    - the argument list, using `parseArgumentStrings`:
        - going over the list, it passes all elements starting with '-' to `parseArgumentCharacters`, a wrapper to send each character into `parseArgumentCharacter`, where:
            - an `ArgumentMarshaler` is gotten from the `marshalers` map for the character. 
            - we use the gotten marshaler object to `set(argument)`:
                - the correct parameter argument is then assigned to the object's variable.


## Instructions on running, executing, prerequisites

### Install/Update Java
* sudo add-apt-repository ppa:openjdk-r/ppa
* sudo apt-get update -q 
* sudo apt install -y openjdk-11-jdk 

### For The Main File

* Clone this repo 
* install ant by running 'sudo apt-get install ant'
* then go to the folder where you have cloned this repo
* run 'ant compile'
* run 'ant jar'
* run 'java -cp build/jar/args.jar com.cleancoder.args.ArgsMain'

### For the tests

* Run the command given below from the root folder of this repo
* 'java -cp "lib/junit-4.13.jar:lib/hamcrest-core-1.3.jar:build/jar/args.jar" ./test/com/cleancoder/args/ArgsTest.java testCreateWithNoSchemaOrArguments'
 

## Changes made to "clean" the code

The original file is rather opaque in its implementation, as a result of which:

- It takes time to understand what the purpose of the code is
- It also takes time to understand how something works, even knowing its purpose

On top of that, a complete lack of any comments whatsoever (even where it could benefit from them) means that the already poorly written code is rather incomprehensible.

### Changing the control flow of the program

- In the original file, each set of operations (parse schema, parse arguments) is done entirely linearly. Each function does one thing (or more) and then calls another function, and we are left to understand from this what happens by following the entire thing:
    - **Solution:** Each operation is done through a central function. For instance, `setSchema` calls a function (`listifySchema`) to split the schema into individually operable schema definitions, then calls a function (`validateSchemaElementId`) to validate it, and then calls `mapArgToMarshaler` to do the actual mapping, which is the schema set operation.

### Changing the structure of Args.java

- **Moved the public functions up to the top of the file:** Since an external programmer implementing the library does not care about the functioning of the library but rather the functions available to them, the public functions (`getInt`, `getString`, etc.) are moved above.
- **`validateSchemaElementId` is called from `setSchema`, not alongside `parseSchemaElement`**: One function, one task
- **validateSchemaElementId works with String instead of char** for better generalisation.
- **`setSchema` that calls all schema-setting functions sequentially**, instead of the previous function relay-race. Added semantics.
- **Replaced `for` loop in `parseArgumentStrings` with `while`**, it clears up usage of the loop without much addition to complexity.

### Changing the function names, adding and removing functions

- **Removing unnecessary functions**:
    - `parseArgumentCharacters` is unnecessary, and adds complexity where not required. Replaced with a single command `<String>.toCharArray()` in `parseArguments`
- **Adding useful functions**:
    - `setSchema`, adds more semantic information.
    - `listifySchema` takes the place of the erstwhile `parseSchema`, in terms of splitting the schema into individual elements. `ArrayList` is used instead of arrays, for mutability.
    - `getMarshaler` replaces `argToMarshaler.get(<character>)`, to make more sense in sentences. It also increases modularity.
- **Making function names more useful**:
    - `parseSchema` was changed to `setSchema`, as the setting is a more primary function than parsing. (the originally functionality was also swapped out)
    - `parseSchemaElement` is now `mapArgToMarshaler`, for better semantics.
    - `parseArguments` instead of `parseArgumentStrings`; lego naming
    - `parseArgumentCharacter` is now `argumentHandler`, as it makes more sense.

### Changing the variable names

A number of variable names were changed to better explain what exactly it is they do.

| **Original**                   | **New**                   |
|--------------------------------|---------------------------|
| marshalers                     | argToMarshaler            |
| currentArgument                | argIterator               |
|                                | schemaList                |
| element (inside `parseSchema`) | schemaElement             |
|                                | subArgs                   |
| argString                      | arg                       |
| argChars                       |                           |
| m                              | am (following convention) |

## Added Tests

- `testMulticharArguments`, checking that if we do `"-xy", "42", "69"`, then `getInt('x')` returns 42, and `getInt('y')` returns 69.

