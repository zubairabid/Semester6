package com.cleancoder.args;

import java.util.*;

import static com.cleancoder.args.ArgsException.ErrorCode.*;

public class Args {
    private Map<Character, ArgumentMarshaler> argToMarshaler;
    private Set<Character> argsFound;
    private ListIterator<String> argIterator;

    public Args(String schema, String[] args) throws ArgsException {
        argToMarshaler = new HashMap<Character, ArgumentMarshaler>();
        argsFound = new HashSet<Character>();

        setSchema(schema);
        parseArguments(Arrays.asList(args));
    }

    public boolean has(char arg) {
        return argsFound.contains(arg);
    }

    public int nextArgument() {
        return argIterator.nextIndex();
    }

    public boolean getBoolean(char arg) {
        return BooleanArgumentMarshaler.getValue(getMarshaler(arg));
    }

    public String getString(char arg) {
        return StringArgumentMarshaler.getValue(getMarshaler(arg));
    }

    public int getInt(char arg) {
        return IntegerArgumentMarshaler.getValue(getMarshaler(arg));
    }

    public double getDouble(char arg) {
        return DoubleArgumentMarshaler.getValue(getMarshaler(arg));
    }

    public String[] getStringArray(char arg) {
        return StringArrayArgumentMarshaler.getValue(getMarshaler(arg));
    }

    public Map<String, String> getMap(char arg) {
        return MapArgumentMarshaler.getValue(getMarshaler(arg));
    }

    private ArgumentMarshaler getMarshaler(char args) {
        return argToMarshaler.get(args);
    } 

    private void setSchema(String schema) throws ArgsException {
        ArrayList<String> schemaList = listifySchema(schema);
        for (String schemaElement : schemaList) {
            validateSchemaElementId(schemaElement);
            mapArgToMarshaler(schemaElement);
        }
    }

    private ArrayList<String> listifySchema(String schema) throws ArgsException {
        ArrayList<String> schemaList = new ArrayList<String>();

        for (String element : schema.split(","))
            if (element.length() > 0)
                schemaList.add(element.trim());

        return schemaList;
    }

    private void mapArgToMarshaler(String element) throws ArgsException {
        char elementId = element.charAt(0);
        String elementTail = element.substring(1);
        
        if (elementTail.length() == 0)
            argToMarshaler.put(elementId, new BooleanArgumentMarshaler());
        else if (elementTail.equals("*"))
            argToMarshaler.put(elementId, new StringArgumentMarshaler());
        else if (elementTail.equals("#"))
            argToMarshaler.put(elementId, new IntegerArgumentMarshaler());
        else if (elementTail.equals("##"))
            argToMarshaler.put(elementId, new DoubleArgumentMarshaler());
        else if (elementTail.equals("[*]"))
            argToMarshaler.put(elementId, new StringArrayArgumentMarshaler());
        else if (elementTail.equals("&"))
            argToMarshaler.put(elementId, new MapArgumentMarshaler());
        else
            throw new ArgsException(INVALID_ARGUMENT_FORMAT, elementId, elementTail);
    }

    private void validateSchemaElementId(String schemaElement) throws ArgsException {
        if (!Character.isLetter(schemaElement.charAt(0)))
            throw new ArgsException(INVALID_ARGUMENT_NAME, schemaElement.charAt(0), null);
    }

    private void parseArguments(List<String> argsList) throws ArgsException {
        argIterator = argsList.listIterator();
        while (argIterator.hasNext()) {
            String arg = argIterator.next();
            if (arg.startsWith("-")) {
                char[] subArgs = arg.substring(1).toCharArray();
                for (char argChar : subArgs)
                    argumentHandler(argChar);
            } else {
                argIterator.previous();
                break;
            }
        }
    }

    private void argumentHandler(char argChar) throws ArgsException {
        ArgumentMarshaler am = getMarshaler(argChar);
        if (am == null) {
            throw new ArgsException(UNEXPECTED_ARGUMENT, argChar, null);
        } else {
            argsFound.add(argChar);
            try {
                am.set(argIterator);
            } catch (ArgsException e) {
                e.setErrorArgumentId(argChar);
                throw e;
            }
        }
    }
}
