Domain		No._of_Sentences	No._of_Tokens
General		    12.5K		    155K

The annotation is funded by DeitY, Govt. of India. 

Each folder contains 2 folders.
1. Documents
2. Data
The dependency annotation follows Paninian Grammar Framework (Guidelines in Documents). The mapping of the dependency labels with the stanford dependency labels are also in the Documents. The annotation follows SSF (Shakti Standard Format), for further details related to SSF, refer the SSF_Guide. 	
